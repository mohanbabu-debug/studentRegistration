from django.apps import AppConfig


class MarkConfig(AppConfig):
    name = 'mark'
